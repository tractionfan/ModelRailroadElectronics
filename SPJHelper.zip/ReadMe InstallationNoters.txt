SPJHelper Installation Notes

(1) Before installing SPJHelper Version 6.2 be sure to remove previous versions (e.g. 4.1, 6.0 or 6.1) using the standard Windows "remove programs" facility.

(2) Unzip SPJHELPER.ZIP into an available temporary folder.

(3) Run SPJHelper.exe from that folder

(4) Be aware that Windows caches program ini files (SPJHelper.INI which is
    used to save data between runs) rather than the program folder as in earlier Windows versions.
    The cache is not removed when SPJHelper is uninstalled. This MAY result in an error message stating
    SPJHelper cannot find a project file (from a project created in the previous version.) Simply use
    the "Work on a project in another folder" option to locate a desired project.