/**********************************************************************
LNetCmdStation.cpp
COPYRIGHT (c) 2016 Dani Guisado,  Mods by F.MILLER 6/2020
Command Station Loconet implementation
**********************************************************************
This 3/27/20 version "fools" loconet to send opposite direction commands
It also has not solved the "refresh" if the display after a poweroff if
had already selected a loco which is active.  Dir and speed commands do
fill in but not address.
6/2020 mods add display of fct 0-4 settings
**********************************************************************/
#include "LNetCmdStation.h"
#include "DCCpp_Uno.h"

volatile RegisterList *LNetCmdStation::mRegs;
volatile RegisterList *LNetCmdStation::pRegs;
CurrentMonitor *LNetCmdStation::mMonitor;
LiquidCrystal *mLcd;

void LNetCmdStation::init(volatile RegisterList *_mRegs, volatile RegisterList *_pRegs, CurrentMonitor *_mMonitor, LiquidCrystal *_mLcd)
{  
  mRegs=_mRegs;
  pRegs=_pRegs;
  mMonitor=_mMonitor;
  mLcd=_mLcd;
  
  int n;                    // initialize all slots to FREE at startup
  for (n=0;n<MAX_MAIN_REGISTERS;n++)  {
    locoNetSlots[n].command=0xE7;
    locoNetSlots[n].mesg_size=0x0E;
    locoNetSlots[n].slot=n+1;
    locoNetSlots[n].stat=LOCO_FREE | DEC_MODE_128;
    locoNetSlots[n].adr=0;
    locoNetSlots[n].spd=0;
    locoNetSlots[n].dirf=0;       //NO direction or Functions
    locoNetSlots[n].trk = GTRK_POWER & GTRK_MLOK1; // POWER ON & Loconet 1.1 by default
    locoNetSlots[n].ss2=0;
    locoNetSlots[n].adr2=0;
    locoNetSlots[n].snd=0;
    locoNetSlots[n].id1=0;
    locoNetSlots[n].id2=0;
  }
}

void LNetCmdStation::checkPacket() {
  LnPacket = LocoNet.receive();  // Check for any received LocoNet packets
  if (LnPacket)  {    
    processIncomingLoconetCommand();
  }
}

void LNetCmdStation::sendOPC_GP(byte on) {
  lnMsg SendPacket;
  if (on==ON) {
     SendPacket.data[ 0 ] = OPC_GPON;            
  } 
  else if (on==OFF)  {
     SendPacket.data[ 0 ] = OPC_GPOFF;             
  } else {
     SendPacket.data[ 0 ] = OPC_IDLE;  
  }
  LocoNet.send( &SendPacket ) ;
}

void LNetCmdStation::processIncomingLoconetCommand() {  
  int n;
  int freeslot=MAX_MAIN_REGISTERS;
  unsigned char opcode = (int)LnPacket->sz.command;
  char s[20];
  byte myByte;
  int myAddress;
  int cvnum=0;
  int cvvalue=0;
  int tAddr;
  int tNum;
  int tAct;

  switch (opcode)  {
    case OPC_GPON:                      //Global ON command
      Serial.println("# GLOBAL ON #");        
      mLcd->setCursor(0,0);             // set the LCD cursor   position 
//-----------------
//      mLcd->print("PWR:ON FCT:-----");
//-----------------
      
      mLcd->print(" TRACK POWER ON ");
//      mLcd->setCursor(0,1);
//      mLcd->print("LN#:-- D:- S:---");   
      mMonitor->setGlobalPower(ON);
      break;
      
    case OPC_GPOFF:                     // Global OFF command
      Serial.println("# GLOBAL OFF #");
      mMonitor->setGlobalPower(OFF);
      mLcd->setCursor(0,0);             // set the LCD cursor   position 
      mLcd->print(" TRACK POWER OFF");   
//      mLcd->setCursor(0,1);
//      mLcd->print("RESET W/POWER ON");   
      break;

    case OPC_IDLE: //Stop emergency
      Serial.println("# EMERGENCY STOP #");
      mMonitor->setGlobalPower(EMERGENCY);
      mLcd->setCursor(0,0);             // set the LCD cursor position 
      mLcd->print(" EMERGENCY STOP ");
//      mLcd->setCursor(0,1);
//      mLcd->print("RESET W/POWER ON");   
      break;
 
    case OPC_LOCO_ADR: // Request of Loco
      Serial.println("# OPC_LOCO_ADR Request of Loco #");
      //Check if it is in slot already and also gets the first possible free slot
      //Slot 0 is not examined as it is used as BT2 slot (TODO not implemented)
      
      for (n=1;n<MAX_MAIN_REGISTERS;n++) {
        if (((locoNetSlots[n].stat & LOCOSTAT_MASK) == LOCO_FREE) && n<MAX_MAIN_REGISTERS) 
          freeslot=n;
        else if (locoNetSlots[n].adr==LnPacket->la.adr_lo && locoNetSlots[n].adr2==LnPacket->la.adr_hi) 
          break;
      }
 
      if (n==MAX_MAIN_REGISTERS && freeslot==MAX_MAIN_REGISTERS)  { //Loco not found and no free slots
        Serial.println("# !LONGACK! No free slots for loco #");
        LocoNet.sendLongAck(0);
        break;
      }
      
      if (n==MAX_MAIN_REGISTERS)      //Loco not found, out in first free slot speed 0, direction front, F0 ON
      {
        n=freeslot;
        locoNetSlots[n].command=0xE7;
        locoNetSlots[n].mesg_size=0x0E;
        locoNetSlots[n].slot=n;
        locoNetSlots[n].stat=LOCO_IDLE | DEC_MODE_128;
        locoNetSlots[n].adr=LnPacket->la.adr_lo;
        locoNetSlots[n].spd=0;
        locoNetSlots[n].dirf=48; //DIRF_F0;       //Forward and no Functions
        locoNetSlots[n].trk &= GTRK_POWER & GTRK_MLOK1; // POWER ON & Loconet 1.1 by default
        locoNetSlots[n].ss2=0;
        locoNetSlots[n].adr2=LnPacket->la.adr_hi;
        locoNetSlots[n].snd=0;
        locoNetSlots[n].id1=0;
        locoNetSlots[n].id2=0;
      }    
      Serial.println("# SLOT SENT #");
      LocoNet.send ((lnMsg*)&locoNetSlots[n]);
      break;
 
    case OPC_MOVE_SLOTS:
      Serial.println("# OPC_MOVE_SLOTS #");      // Throttle dropped address?
      mLcd->setCursor(0,1);                      // set the LCD cursor position 
      mLcd->print("LN#:-- D:- S:---");
      //Check slot range (0 DISPATCH NOT SUPPORTED, DIFFERENT NOT SUPPORTED)
      if (LnPacket->sm.dest>=MAX_MAIN_REGISTERS || LnPacket->sm.src>=MAX_MAIN_REGISTERS || LnPacket->sm.dest!=LnPacket->sm.src || LnPacket->sm.dest<1 || LnPacket->sm.src<1)
      {                                           // yes, Throttle dropped address
//      mLcd->setCursor(0,1);                       // set the LCD cursor position 
//      mLcd->print("LN#:-- D:- S:---");
      LocoNet.sendLongAck(0);
      return;
      }
      
      locoNetSlots[LnPacket->sm.dest].stat|=LOCO_IN_USE;    
      LocoNet.send ((lnMsg*)&locoNetSlots[LnPacket->sm.dest]);
      //<t REGISTER CAB SPEED DIRECTION>
      myAddress=locoNetSlots[LnPacket->sm.dest].adr+(locoNetSlots[LnPacket->sm.dest].adr2<<7);
      sprintf(s,"%d %d %d %d",LnPacket->sm.dest,myAddress,locoNetSlots[LnPacket->sm.dest].spd,bitRead(locoNetSlots[LnPacket->sm.dest].dirf,5));

      mLcd->setCursor(4,1);
      mLcd->print(myAddress);
      mLcd->setCursor(9,1);        //show direction
      if (locoNetSlots[LnPacket->sm.dest].dirf==16){
        mLcd->print("F");
      }else{
        mLcd->print("R");         
      }

      mRegs->setThrottle(s);
      // <f CAB BYTE1 [BYTE2]>
      //   To set functions F0-F4 on (=1) or off (=0):
      //   BYTE1:  128 + F1*1 + F2*2 + F3*4 + F4*8 + F0*16
      //   BYTE2:  omitted
      myByte=128;
      bitWrite(myByte,4,bitRead(locoNetSlots[LnPacket->sm.dest].dirf,4)); //F0
      bitWrite(myByte,0,bitRead(locoNetSlots[LnPacket->sm.dest].dirf,0)); //F1
      bitWrite(myByte,1,bitRead(locoNetSlots[LnPacket->sm.dest].dirf,1)); //F2
      bitWrite(myByte,2,bitRead(locoNetSlots[LnPacket->sm.dest].dirf,2)); //F3
      bitWrite(myByte,3,bitRead(locoNetSlots[LnPacket->sm.dest].dirf,3)); //F4
      sprintf(s,"%d %d",myAddress,myByte);      
      mRegs->setFunction(s);      
      break;
      
    case OPC_SLOT_STAT1:
      Serial.println("# OPC_SLOT_STAT1 #");
      locoNetSlots[LnPacket->ss.slot].stat = LnPacket->ss.stat;
      //<t REGISTER CAB SPEED DIRECTION>
      char s[20];
      sprintf(s,"%d %d %d %d",LnPacket->ss.slot,locoNetSlots[LnPacket->ss.slot].adr,locoNetSlots[LnPacket->ss.slot].spd,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,5));
//      mainRegs.setThrottle(s);
      break;
      
    case OPC_LOCO_SPD:
      if (locoNetSlots[LnPacket->lsp.slot].adr >0){
      Serial.println("# OPC_LOCO_SPD #");
      locoNetSlots[LnPacket->lsp.slot].spd = LnPacket->lsp.spd;
      //<t REGISTER CAB SPEED DIRECTION>
      myAddress=locoNetSlots[LnPacket->lsp.slot].adr+(locoNetSlots[LnPacket->lsp.slot].adr2<<7);
      sprintf(s,"%d %d %d %d",LnPacket->lsp.slot,myAddress,locoNetSlots[LnPacket->lsp.slot].spd,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,5));
      mRegs->setThrottle(s);
      mLcd->setCursor(13,1);
      mLcd->print("   ");             //blank out prev speed displauy
      mLcd->setCursor(13,1);         //show new speed setting
      mLcd->print(locoNetSlots[LnPacket->lsp.slot].spd);
      }
      break;
      
    case OPC_LOCO_DIRF:
      if (locoNetSlots[LnPacket->lsp.slot].adr >0){
      Serial.print("# OPC_LOCO_DIRF # Diretion and F0 - F4 # ");
      Serial.println(locoNetSlots[LnPacket->ldf.slot].dirf,BIN);

      locoNetSlots[LnPacket->ldf.slot].dirf = LnPacket->ldf.dirf ^ 32;  //*** reverse direction (flip bit 5 0010 0000
      //<t REGISTER CAB SPEED DIRECTION>
      myAddress=locoNetSlots[LnPacket->lsp.slot].adr+(locoNetSlots[LnPacket->lsp.slot].adr2<<7);

      sprintf(s,"%d %d %d %d",LnPacket->ldf.slot,myAddress,locoNetSlots[LnPacket->ldf.slot].spd,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,5));      
//--------------------------------------
      mLcd->setCursor(9,1);        //show direction
      if (bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,5) == 1){   //look at bit 5 (0010 0000)
        mLcd->print("F");
      }else{
        mLcd->print("R");         
      }
      mRegs->setThrottle(s);
//---------------------------------------
  
      // <f CAB BYTE1 [BYTE2]>
      //   To set functions F0-F4 on (=1) or off (=0):
      //   BYTE1:  128 + F1*1 + F2*2 + F3*4 + F4*8 + F0*16
      //   BYTE2:  omitted
      myByte=128;      
      bitWrite(myByte,0,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,0)); //F1
      bitWrite(myByte,1,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,1)); //F2
      bitWrite(myByte,2,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,2)); //F3
      bitWrite(myByte,3,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,3)); //F4
      bitWrite(myByte,4,bitRead(locoNetSlots[LnPacket->ldf.slot].dirf,4)); //F0
      sprintf(s,"%d %d",myAddress,myByte);      
/*
      mLcd->setCursor(11,0);
      if ((myByte & 16) == 0){    //F0
        mLcd->print("-");               
      }else{
        mLcd->print("0");         
      }       
      mLcd->setCursor(12,0);
      if ((myByte & 1) == 0){     //F1
        mLcd->print("-");               
      }else{
        mLcd->print("1");         
      }       
      mLcd->setCursor(13,0);
      if ((myByte & 2) == 0){     //F2
        mLcd->print("-");               
      }else{
        mLcd->print("2");         
      }       
      mLcd->setCursor(14,0);      
      if ((myByte & 4) == 0){     //F3
        mLcd->print("-");               
      }else{
        mLcd->print("3");         
      }       
      mLcd->setCursor(15,0);
      if ((myByte & 8) == 0){   //F4
        mLcd->print("-");               
      }else{
        mLcd->print("4");         
      }       
*/
      mRegs->setFunction(s);

      }
      break;
      
    case OPC_LOCO_SND:                  //function settings
      Serial.println("# OPC_LOCO_SND #");
      locoNetSlots[LnPacket->ls.slot].snd = LnPacket->ls.snd;
      //*    To set functions F5-F8 on (=1) or off (=0):
      //*   
      //*    BYTE1:  176 + F5*1 + F6*2 + F7*4 + F8*8
      //*    BYTE2:  omitted
      myAddress=locoNetSlots[LnPacket->lsp.slot].adr+(locoNetSlots[LnPacket->lsp.slot].adr2<<7);
      myByte=176;      
      bitWrite(myByte,0,bitRead(locoNetSlots[LnPacket->ls.slot].snd,0)); //F5
      bitWrite(myByte,1,bitRead(locoNetSlots[LnPacket->ls.slot].snd,1)); //F6
      bitWrite(myByte,2,bitRead(locoNetSlots[LnPacket->ls.slot].snd,2)); //F7
      bitWrite(myByte,3,bitRead(locoNetSlots[LnPacket->ls.slot].snd,3)); //F8      
      sprintf(s,"%d %d",myAddress,myByte);      
      mRegs->setFunction(s);
      break;

    case OPC_SW_REQ:

      tAddr = (LnPacket->srq.sw1 | ((LnPacket->srq.sw2 & 0x0F) <<7));
      tAddr++;
      tNum = 0;
      tAct = LnPacket->srq.sw2 & OPC_SW_REQ_DIR; 
      sprintf(s,"%d %d %d",tAddr,tNum,tAct);
      mRegs->setAccessory(s);
      break;
      
    default:        // ignore the message... (ALL PROGRAMMING CMDS IGNORED)
      Serial.println("# !! IGNORE MESSAGE !! #");
      break;            
  }
}
