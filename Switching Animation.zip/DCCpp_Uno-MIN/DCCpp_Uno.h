/**********************************************************************
DCCpp_Uno.h
COPYRIGHT (c) 2013-2016 Gregg E. Berman,  Mods by F.Miller
Part of DCC++ BASE STATION for the Arduino
**********************************************************************/
  #ifndef DCCpp_Uno_h
  #define DCCpp_Uno_h
  
  #define VERSION "2-UNO"
  #define ARDUINO_TYPE "UNO"
  #define DCC_SIGNAL_PIN_MAIN 10          // Ardunio Uno  - uses OC1B
  #define DCC_SIGNAL_PIN_PROG 5           // Arduino Uno  - uses OC0B
  #define MOTOR_SHIELD_NAME "ARDUINO MOTOR SHIELD"
  #define SIGNAL_ENABLE_PIN_MAIN 3
  #define SIGNAL_ENABLE_PIN_PROG 11
  #define CURRENT_MONITOR_PIN_MAIN A0
  #define CURRENT_MONITOR_PIN_PROG A1
  #define DIRECTION_MOTOR_CHANNEL_PIN_A 12
  #define DIRECTION_MOTOR_CHANNEL_PIN_B 13
  #define COMM_TYPE 0
  #define INTERFACE Serial

  #define SHOW_PACKETS  0       // set to zero to disable printing of every packet for select main operations track commands

  #define MOTOR_SHIELD_TYPE   0         //ARDUINO MOTOR SHIELD (MAX 18V/2A PER CHANNEL)
  #define MAX_MAIN_REGISTERS 12
  #define COMM_INTERFACE   0            //Built-in Serial Port
#endif
