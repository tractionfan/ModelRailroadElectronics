/**********************************************************************
  SerialCommand.cpp
  COPYRIGHT (c) 2013-2016 Gregg E. Berman
  Part of DCC++ BASE STATION for the Arduino
  Changes by F. Miller 5/24/2021
  -Removed all cmds except:  0,1,t,f,a
  -Removed reference to COM_TYPE (only using Serial)
**********************************************************************/

// DCC++ BASE STATION COMMUNICATES VIA THE SERIAL PORT USING SINGLE-CHARACTER TEXT COMMANDS
// WITH OPTIONAL PARAMTERS, AND BRACKETED BY < AND > SYMBOLS.  SPACES BETWEEN PARAMETERS
// ARE REQUIRED.  SPACES ANYWHERE ELSE ARE IGNORED.  A SPACE BETWEEN THE SINGLE-CHARACTER
// COMMAND AND THE FIRST PARAMETER IS ALSO NOT REQUIRED.

#include "SerialCommand.h"
#include "DCCpp_Uno.h"

extern int __heap_start, *__brkval;
char SerialCommand::commandString[MAX_COMMAND_LENGTH + 1];
volatile RegisterList *SerialCommand::mRegs;
volatile RegisterList *SerialCommand::pRegs;
CurrentMonitor *SerialCommand::mMonitor;

void SerialCommand::init(volatile RegisterList *_mRegs, volatile RegisterList *_pRegs, CurrentMonitor *_mMonitor) {
  mRegs = _mRegs;
  pRegs = _pRegs;
  mMonitor = _mMonitor;
  sprintf(commandString, "");
}

void SerialCommand::process() {
  char c;

  while (INTERFACE.available() > 0) { // while there is data on the serial line
    c = INTERFACE.read();
    if (c == '<')                 // start of new command
      sprintf(commandString, "");
    else if (c == '>')            // end of new command
      parse(commandString);
    else if (strlen(commandString) < MAX_COMMAND_LENGTH) // if comandString still has space, append character just read from serial line
      sprintf(commandString, "%s%c", commandString, c);  // otherwise, character is ignored (but continue to look for '<' or '>')
  }
}

void SerialCommand::parse(char *com) {
  switch (com[0]) {

    /***** OPERATE TURNOUTS (STATIONARY ACCESSORY DECODERS)  ****/    
    case 'a':       // <a ADDRESS SUBADDRESS ACTIVATE>
                    // ADDRESS = INT((N - 1) / 4) + 1 (N is digitrax SW id)
                    // SUBADDRESS = (N - 1) % 4
                    // So Sw 100 = 25 3
                    // ACTIVATE: 1=on (CLOSED), 0=off (THROWN)
      mRegs->setAccessory(com+1);
      break;

    /***** SET ENGINE THROTTLES USING 128-STEP SPEED CONTROL ****/
    case 't':       // <t REGISTER CAB SPEED DIRECTION>
      mRegs->setThrottle(com + 1);
      break;

    /***** TURN ON POWER FROM MOTOR SHIELD TO TRACKS  ****/
    case '1':      // <1>
      digitalWrite(SIGNAL_ENABLE_PIN_MAIN, HIGH);
      INTERFACE.println("Pwr ON");
      digitalWrite(onLED, HIGH);            //show power ON            
      break;

    /***** TURN OFF POWER FROM MOTOR SHIELD TO TRACKS  ****/
    case '0':     // <0>
      digitalWrite(SIGNAL_ENABLE_PIN_MAIN, LOW);
      INTERFACE.println("Pwr OFF");
      digitalWrite(onLED, LOW);             //show power OFF
      break;
      
    /***** OPERATE ENGINE DECODER FUNCTIONS F0-F28 ****/
    case 'f':       // <f CAB BYTE1 [BYTE2]>
      mRegs->setFunction(com + 1);
      String fcm = commandString;
      INTERFACE.print("Fcts ON:");
      int xcmd = fcm.substring(5).toInt();
      if (bitRead(xcmd, 5) == 0) {              //means F0 - F3
        if (bitRead(xcmd, 4) == 1 && bitRead(xcmd, 3) == 0) {
          INTERFACE.print("F0 ");
        }
        if (bitRead(xcmd, 0) == 1) {
          INTERFACE.print("F1 ");
        }
        if (bitRead(xcmd, 1) == 1) {
          INTERFACE.print("F2 ");
        }
        if (bitRead(xcmd, 2) == 1) {
          INTERFACE.print("F3 ");
        }
      } else {
        if(bitRead(xcmd, 4) == 1 && bitRead(xcmd, 3) == 1){ 
        INTERFACE.print("F8 (MUTE) ");
        }
      }
      if (xcmd == 128 ) {INTERFACE.print("NONE");}
      if (xcmd == 176) {INTERFACE.print("MUTE OFF");}
      INTERFACE.println("");
      break;
  }
}
