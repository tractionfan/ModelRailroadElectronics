SPJViewer Installation Notes
Unzip the SPJViewer.zip file into an available (temp) folder.
Run SETUP from that folder