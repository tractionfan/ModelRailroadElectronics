/******************************************************************************************
 * This library must be 'located' in the base sketch folder, e.g. 'N_Animation-Mega-SDHC-Vxx'
 ****************************************************************************************** 
 Display of the layout switches and detections on 128x32 SSD1306 I2C OLED is provided on an
 Arduino PRO MIN running Script 'Slave_SSD1306_LayoutDisplay V2.
 Display of the Operational Status on 128x64 (running as 128x32) SSD1306 I2C OLED is provided
 on an Arduino PRO MIN running Script 'Slave_SSD1306_StatusDisplay V4.
 NEW: Voice messages are provided on an ATTINY85 running a DFPLAYER.
 Communication to these PRO MINI and ATTINY85 is through I2C messages passed through an I2C switch.
 All graphics and constants are self contained in the PRO MINI sketches.
 Commands sent to LayoutDisplay: (Single byte sent through I2C communication)
  1-6  = TURNOUTS 1-6 THROWN; 11-16  =  TURNOUTS 1-6 CLOSED
 21-26 = DET 1-6 ON;          31-36  =  DET 1-6 OFF
 Commands sent to StatusDisplay consist of a 3-byte message sent through I2C communication
 Commands sent to DFPlayer consist of a 2-byte message sent through the I2C communication
 (See Excel document 'StatusDisplays.xlsx' and 'Slave_SSD1306_StatusDisplay-V4.in0' for
 description of commands and associated texts' 
 *******************************************************************************************
 Constants for this MEGA control version are also included in this N_Animation-Addendum file
 ******************************************************************************************* 
   FIX LIST - N_Animation-MEGA as of Version 28
   This version uses either SDHC card or an internal table for script
   reference to the sub loops. (Selection based on IntTable=true/false) 
   (First line of SDHC is the sketch name - 14 positions)
   Special Motor sounds OFF/ON during uncoupling compensate for LokSound decoder problem
   Includes provision for stopping on # cars past det (in EB, uncEB, WB and uncWB runs)
   Fix 1/15/20 to allow uncoupling within a string of cars, not just trailing car
   Fix 1/19/20 to adjust moves counter to NOT count uncouple jiggle move
   Fix 1/30/20 to better internal table organization and use.
   Fix 3/13/20 corrected Ramp::Detector relationship, added delays after switch action
      and fixed display for DET or TIMED after uncoupling
   Fix 3/14/20 added 'pause' function and use of Internal table if no card.  Also inits all
      turnouts to CLOSED at startup.
   Fix 4/4/20 added speed parameter as Parm5 in script (each EB/WB motion has own speed)
      added "PAUSE" display message when doing Action 7
   Fix 4/26/20 moved display init to last in setup (ensure gets activated) and fixed display
      of sketch title (14 bytes not included crlf)
   Fix 5/3/20 added support for 'timed' event 0f 0; also display timed movement count
   Fix 6/10/20 replaced runsw toggle with SPDT & SPST toggles to set Mode. An analog
      read determines Mode:
      Mode 0: (HOLD) RED/GRN Blink (analog ~509) - no toggles set (SPDT in center position)
      Mode 1: (NORMAL)  GRN LED (analog ~937) - SPDT set to Normal
      Mode 2: (SINGLESTEP) AMBER COLOR) (analog ~604) - SPDT set to Single Step
      Mode 3: (Testing - tbd) RED Blink (analog ~ 0)  - SPST set to ON
      Either a Solid RED OR YELLOW shown during Pauses & showStop
      If 'HOLD' mode set during NORMAL OPS, blinking Green until finish sketch
      Both SINGLESTEP and TEST Mode use a PB to advance.
   Fix 6/19/20 changed detection 'blobs' to det #s (1-6);  added detection 6
   Fix 7/18/20 improved detection 'blobs' to include Det # (black on white) & improved screen 
   Fix 7/23/20 shifted detection 'blobs' to second oled display, added I2C MUX, moved some
      some constants and definitions to 'layoutDisplay.h'
   Fix 7/29/20 removed 'test mode'.  Fixed various op bugs dealing with reading SDHC/Tables
   Fix 8/9/20 ( v18 with reconstructed fixes from previous v19,20 )
      increased Action Tick time to 200 (time to do F8) at startup, but reduced to 100 after prep
      added display of External Switch Cmds.  Fixed display borders
      fixed stop speed (1 instead of 0 to get full stop)
      added POWER ON cmd at end of PrepWork,  moved mode text to table & modified msg blanking
   Fix 8/10/20 Action clock starts at 300, reset to 100 after PrepWork done.
      Speed decrements modified for faster stopping. Moved ramp1Pin from 4 to 24 and ramp2Pin
      from 3 to 25 (?? D4 conflicts with something in SSD1306 libraries).
   Fix 8/11/20 set appropriate detector for specific ramp
   Fixes 8/28-31 All 'Switch/case' changed to 'else if'     
      New I2C message formats to run Status and Layout Displays  
      Added back display of steps & moves and showStop/ShowRun
      Supports display of externally generated switch commands (e.g. throttles)
      Action 8 (Trigger Ramp) removed - not necessary
      Actions (0-7) Are individually activated in loop() as per Schedule line read in the 
      NextEvent. Actions are either single or multiple steps.
      Parms for each action are set up when Schedule line is read in NextEvent
   Fix 9/15/20 - removed 'afteruncouple' boolean - obsolete logic.  Added Det-to-Ramp
      association. Adjusted delayTimer-ramp jiggle to '12'
   Fix 9/20/20 - fixed display of TIMED # to be capable of >255 by using
      z byte parameter to indicate amount over 255.  (Display Status code also
      needed to be changed.)
   Fix 9/21/20 - added a check in Prepwork for any detectors left ON with HOLD until released
   fIX 10/12/20 - added Mute at Uncouple to EB (as was in WB)
   Fix 10/18/20 - replaced entire EBUNC with (adjusted) copy of WBUNC - seems to have eliminated
      occasional failure to 'jiggle'
   Fix/Modification 10/23/20 - Coupler sounds changed to 0=none, 1=Clank/Hiss sequence at start
      of ebrun/wbrun, 2=at end of ebrun/wbrun. Not provided for unceb/uncwb.
   Mod 10/25/20 - added pb selection of schedule line (while in 'hold' mode=0)
   Mod 10/31/20 - added voice sound clips function, removed 'trigger ramp' cmd
   Fix 11/7/20 - added set volume cmd at startup (and player modified to do vol setting)   
   Fix 11/17/20 - put back gradual speed increase in RunEB() step 6
   Mod 11/21/20 - added 'bad card' and 'plus..(car cnt)' verbal messages
   Mod 12/6/20 - added xing ON/OFF cmds executed either at a detection, or a count down
   Fix 12/15/20 - fixed '2nd-time around only' on detection
   Fix 12/20/20 - changed to a loop() count of 3 for detection acknowledgement
   fIX 12/30/20 - reduced speed by 1/2 when approaching EB and WB Ramps (better positioning)
**********************************************************************************************/     
/*   SOUND CLIPS ON SDHC SOUNDS CARD (as of 11/21/20)
CLIP01.MP3 "ONE"
CLIP02.MP3 "TWO"
CLIP03.MP3 "THREE"
CLIP04.MP3 "FOUR"
CLIP05.MP3 "FIVE"
CLIP06.MP3 "SIX"
CLIP07.MP3 "THROW TURNOUT"
CLIP08.MP3 "CLOSE TURNOUT"
CLIP09.MP3 "RUN EASTBOUND TO DETECTOR"
CLIP10.MP3 "RUN EASTBOUND TIMED"
CLIP11.MP3 "UNCOUPLE EASTBOUND TO DETECTOR"
CLIP12.MP3 "UNCOUPLE EASTBOUND TIMED"
CLIP13.MP3 "RUN WESTBOUND TO DETECTOR"
CLIP14.MP3 "RUN WESTBOUND TIMED"
CLIP15.MP3 "UNCOUPLE WESTBOUND TO DETECTOR"
CLIP16.MP3 "UNCOUPLE WESTBOUND TIMED"
CLIP17.MP3 "FIX DETECTORS"
CLIP18.MP3 "ACQUIRE LOCO"
CLIP19.MP3 "SELECT MODE"
CLIP20.MP3 "NORMAL OPS"
CLIP21.MP3 "SINGLE STEP OPS"
CLIP22.MP3 "BAD CARD"
CLIP23.MP3 "PLUS" 
*/

//================ Internal Parms Table (Used in lieu of SDHC if not present) ================

int IX = 0;                //index into Internal Table 
const char * ITable [] {   //Table entries MUST be 14 char ib length
  "TEST XING",    
  "0,000,0,0,0,00", //RUN SWITCH
  "8,230,0,0,0,00", //XING PENDING ON
  "4,280,0,1,0,15", //UNCEB PUSH TO S5
  "7,050,0,0,0,00", //PAUSE
  "8,080,1,0,0,00", //XING PENDING OFF
  "2,003,0,0,1,10", //RUN WB
  "8,180,0,0,0,00", //XING PENDING ON
  "1,006,0,0,0,15", //EB TO PICKUP 
  "7,050,0,0,0,00", //PAUSE
  "8,150,1,0,0,00", //XING PENDING OFF  
  "2,003,0,0,2,10", //RUN WB (2 CARS)
  "6,000,0,0,0,00"
};
